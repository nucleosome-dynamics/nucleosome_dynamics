# NucleosomeDynamics

R package aimed at comparing the reads of two MNase-seq experiments for nucleosome positioning
